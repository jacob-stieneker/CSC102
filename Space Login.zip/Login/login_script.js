function checkcreds() {
// Define Variables
var username = document.getElementById("Name").value;
var badgenum = document.getElementById("BadgeNumber").value;
// Login Conditions //
if (username.length <= 20 && username == "jacobstieneker" && badgenum.length == 3 && badgenum == 413) {
    let text = "Access Granted";
    let result = text.fontcolor("lightgreen");
    document.getElementById("LoginStatus").innerHTML = result;
}
else {
    document.getElementById("LoginStatus").innerHTML = "Access Denied";
}

}
