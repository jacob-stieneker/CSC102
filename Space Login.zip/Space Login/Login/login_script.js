function checkcreds() {
// Define Variables
var username = document.getElementById("Name").value;
var badgenum = document.getElementById("BadgeNumber").value;
// Login Conditions //
// Condition for Access Granted//
if (username.length <= 20 && username == "jacobstieneker" && badgenum.length == 3 && badgenum == 413) {
    let text = "Access Granted";
    let result = text.fontcolor("lightgreen");
    document.getElementById("LoginStatus").innerHTML = result;
}
// Condition for Access Denied //
else {
    document.getElementById("LoginStatus").innerHTML = "Access Denied";
}

}
